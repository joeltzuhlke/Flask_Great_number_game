import random
from flask import Flask, render_template, request, redirect, session, Markup
app = Flask(__name__)
app.secret_key ="sKey"
@app.route('/')
def index():
    session['randonNumber'] = random.randint(1,100)
    print session['randonNumber']
    return render_template('index.html')
@app.route('/process', methods=['POST'])
def guess():
    num = int(request.form['number'])
    if num > session['randonNumber']:
        result = "Too high, try again"
    if num < session['randonNumber']:
        result = "Too low, try again"
    if num == session['randonNumber']:
        result = Markup('<form action="/reset" method="post"><input type="submit" value="reset">')
    print num
    print session['randonNumber']
    return render_template ('index.html', result=result)
@app.route('/reset', methods=['POST'])
def reset():
    print "you pressed a button"
    return redirect('/')
app.run(debug=True)